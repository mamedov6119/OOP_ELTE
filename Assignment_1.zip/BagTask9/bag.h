#ifndef PRIORSOR_H_INCLUDED
#define PRIORSOR_H_INCLUDED
#include <string>
#include <iostream>
#include <vector>
#include "read.hpp"
#include <exception>

inline bool valid(int a){return true;}

struct Item
{

    int element;
    int frequency;

    Item(){};
    Item(int element, int frequency): element(element), frequency(frequency) {};

    friend std::istream& operator>>(std::istream& s, Item& e)
    {
        e.element=read<int>("Element: ","Integer is needed!",valid);
        std::cout<<"Frequency: ";
        s>>e.frequency;
        return s;
    }

    friend std::ostream& operator<<(std::ostream& s, const Item& e)
    {
        s<<"("<<e.element<<","<<e.frequency<<")";
        return s;
    }

    bool operator==(const Item& b)
    {
        return (this->element==b.element && this->frequency==b.frequency);
    }



};




class Bag{
    public:
    class ExistingKeyException : public std::exception {};
    class NonExistingKeyException : public std::exception {};
    void insert(Item a);
    void erase(int key);
    int rfrequency(Item a);
    int occured_once();
    int &operator[](int key);
    friend std::ostream& operator<<(std::ostream& s, const Bag& b);
    bool isEmpty() const {return _vec.size() == 0;}
    bool isIn(int key) const;
    int count() const {return _vec.size();}

    std::vector<Item> getItems() const;
    std::pair<bool,int> getLogSearch(int element) const {return logSearch(element);}

    private:
    std::vector<Item> _vec;
    std::pair<bool,int> logSearch(int element) const;

};

#endif // PRIORSOR_H_INCLUDED
