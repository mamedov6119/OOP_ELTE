#include "bag.h"


using namespace std;

void Bag::insert(Item e)
{
    pair<bool, int> out = logSearch(e.element);
    if(!out.first)
    {
        _vec.resize(_vec.size()+1);
        for (int i=_vec.size()-2;i>=out.second;i--) ///unsigned int cannot be used, otherwise (i-2) may become very large :)
        {
            _vec[i+1]=_vec[i];
        }
        _vec[out.second] = e;
    } else {
        throw ExistingKeyException();
    }
}


void Bag::erase(int element)
{
    std::pair<bool,int> out=logSearch(element);
    if (out.first)
    {
        for (unsigned int i=out.second+1;i<_vec.size();i++)
        {
            _vec[i-1]=_vec[i];
        }
        _vec.pop_back();
    }
    else
    {
        throw NonExistingKeyException();
    }
}


int &Bag::operator[](int element)
{
    pair<bool,int> out=logSearch(element);
    if (out.first)
    {
        return _vec[out.second].frequency;
    }
    else
    {
        throw NonExistingKeyException();
    }
}

pair<bool,int> Bag::logSearch(int element) const
{
    bool l=false;
    int lb=0; ///vector numbering starts at 0
    int ub=_vec.size()-1; /// vector numbering finishes at size()-1
    int ind;
    while (!l && lb <= ub)
    {
        ind=(lb+ub)/2;
        if (_vec[ind].element>element) { ub = ind-1; }
        else if (_vec[ind].element<element) { lb = ind+1; }
        else { l= true; }
    }
    if (!l)
    {
        ind = lb;
    }
    return pair<bool,int>(l,ind);
}

ostream& operator<<(std::ostream& s, const Bag& b)
{
    s<<"\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n";
    s<<"Number of elements: "<<b._vec.size()<<"\nContent: "<<endl;
    for(unsigned i=0; i<b._vec.size(); ++i){
        s<<" "<<b._vec[i];
    }
    s<<"\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n";
    return s;
}

int Bag::rfrequency(Item e)
{

    pair<bool,int> out = logSearch(e.element);

    if(out.first) {
        return _vec[out.second].frequency;

    } else {
        throw NonExistingKeyException();
    }




}


bool Bag::isIn(int key) const
{
    return logSearch(key).first;
}


int Bag::occured_once()
{
    int cnt = 0;
    for (unsigned int i = 0; i < _vec.size(); i++) {
        if (_vec[i].frequency == 1) {
            cnt++;
        }

    }

    return cnt;
}



std::vector<Item> Bag::getItems() const
{
    std::vector<Item> v;
    for(unsigned i=0; i<_vec.size(); ++i)
        v.push_back(_vec[i]);
    return v;
}
