﻿#include <iostream>
#include <fstream>
#include "bag.h"
#include "menu.h"
using namespace std;

//#ifndef NORMAL_MODE
#ifdef NORMAL_MODE


int main()
{
    cout << "Bag" << endl;

    Menu menu;
    menu.Run();
}

#else
#define CATCH_CONFIG_MAIN
#include "catch.hpp"



TEST_CASE("creation of an empty bag", "[bag]")
{
    Bag B;
    CHECK(B.isEmpty());

    Item e(1, 3);
    CHECK_FALSE( B.isIn(e.element) );
    B.insert(e);
    CHECK_FALSE(B.isEmpty());
    CHECK(B.isIn(e.element));

    B.erase(e.element);
    CHECK(B.isEmpty());
    CHECK_FALSE(B.isIn(e.element));

}

TEST_CASE("insert","[Bag]")
{
    Bag B;
    Item e1(1, 2); Item e2(2,33); Item e3(3,4); Item e4(4,7); Item e5(5,11);

    B.insert(e2);
    CHECK( 1 == B.count());
    vector<Item> v= B.getItems();
    CHECK( v[0] == e2 );

    B.insert(e5);
    CHECK( 2 == B.count());
    v= B.getItems();
    CHECK( v[0] == e2 ); CHECK( v[1] == e5 );

    B.insert(e1);
    v= B.getItems();
    CHECK( v[0] == e1 ); CHECK( v[1] == e2 ); CHECK( v[2] == e5 );

    B.insert(e3);
    B.insert(e4);
    CHECK( 5 == B.count());
    v= B.getItems();
    CHECK( e1 == v[0]); CHECK( e2 == v[1]); CHECK( e3 == v[2]); CHECK( e4 == v[3]); CHECK( e5 == v[4]);
}

TEST_CASE("logsearch","[Map]")
{
    SECTION("empty Bag")
    {
        Bag B;
        CHECK_FALSE(B.getLogSearch(3).first);
    }

    ///Items for testing
    Item e1(1,1); Item e2(2,4); Item e3(3,6); Item e5(5,10);
    SECTION("one item")
    {
        Bag B;
        B.insert(e1);
        CHECK(B.getLogSearch(e1.element).first);
        CHECK(0 == B.getLogSearch(e1.element).second);
        B.erase(e1.element);
        CHECK( 0 == B.count());
    }

    SECTION("more items, first is searched")
    {
        Bag B;
        B.insert(e5); B.insert(e2); B.insert(e3);
        CHECK(B.getLogSearch(e2.element).first);
        CHECK(0 == B.getLogSearch(e2.element).second);
        B.erase(e2.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e3); CHECK(v[1]==e5);
    }

    SECTION("more items, last is searched")
    {
        Bag B;
        B.insert(e5); B.insert(e2); B.insert(e3);
        CHECK(B.getLogSearch(e5.element).first);
        CHECK(2 == B.getLogSearch(e5.element).second);
        B.erase(e5.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e2); CHECK(v[1]==e3);
    }

    SECTION("more items, middle is searched")
    {
        Bag B;
        B.insert(e5); B.insert(e2); B.insert(e3);
        CHECK(B.getLogSearch(e3.element).first);
        CHECK(1 == B.getLogSearch(e3.element).second);
        B.erase(e3.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e2); CHECK(v[1]==e5);
    }

    SECTION("more items, searched does not exist")
    {
        Bag B;
        B.insert(e5); B.insert(e2); B.insert(e3);
        CHECK_FALSE(B.getLogSearch(e1.element).first);
        CHECK(2 == B.getLogSearch(4).second);
    }
}



TEST_CASE("erase","[Map]")
{
    Item e1(1,2); Item e2(2,4); Item e3(3,6); Item e4(4,8); Item e5(5,10);
    SECTION("erase first")
    {
        Bag B;

        B.insert(e2);
        B.insert(e3);
        B.insert(e1);

        B.erase(e1.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e2); CHECK(v[1]==e3);
    }
    SECTION("erase last")
    {
        Bag B;

        B.insert(e2);
        B.insert(e3);
        B.insert(e1);

        B.erase(e3.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e1); CHECK(v[1]==e2);
    }
    SECTION("erase middle")
    {
        Bag B;

        B.insert(e2);
        B.insert(e3);
        B.insert(e1);

        B.erase(e2.element);
        CHECK( 2 == B.count());
        vector<Item> v=B.getItems();
        CHECK(v[0]==e1); CHECK(v[1]==e3);
    }
}


TEST_CASE("Frequency","[Bag]")
{
    Bag B;
    Item e1(1, 2); Item e2(2,33); Item e3(3,4); Item e4(4,7); Item e5(5,11);

    B.insert(e2);
    CHECK( 1 == B.count());
    CHECK (33 == B.rfrequency(e2));
    vector<Item> v= B.getItems();
    CHECK( v[0] == e2 );

}


TEST_CASE("Occured once","[Bag]")
{
    SECTION ("element occurring once exists"){
    Bag B;
    Item e1(1, 2); Item e2(2,1); Item e3(3,4); Item e4(4,1); Item e5(5,1);
    B.insert(e1);
    B.insert(e2);
    B.insert(e3);
    B.insert(e4);
    B.insert(e5);
    CHECK( 5 == B.count());
    CHECK ( 3 == B.occured_once());
    vector<Item> v= B.getItems();
CHECK( e1 == v[0]); CHECK( e2 == v[1]); CHECK( e3 == v[2]); CHECK( e4 == v[3]); CHECK( e5 == v[4]);
    }

    SECTION ("element occurring once doesn't exist"){
    Bag B;
    Item e1(1, 2); Item e2(2,21); Item e3(3,4); Item e4(4,13); Item e5(5,41);
    B.insert(e1);
    B.insert(e2);
    B.insert(e3);
    B.insert(e4);
    B.insert(e5);
    CHECK( 5 == B.count());
    CHECK ( 0 == B.occured_once());
    vector<Item> v= B.getItems();
CHECK( e1 == v[0]); CHECK( e2 == v[1]); CHECK( e3 == v[2]); CHECK( e4 == v[3]); CHECK( e5 == v[4]);
    }




}


TEST_CASE("exceptions","[Map]")
{
    SECTION("more items, middle is searched")
    {
        Item e1(1,2); Item e2(2,1); Item e3(3,4); Item e5(5,11);
        Bag B;
        CHECK_THROWS(B.erase(2));
        B.insert(e5); B.insert(e2); B.insert(e3);
        CHECK_THROWS(B.insert(e5));
        CHECK_THROWS(B.insert(e2));
        CHECK_THROWS(B.insert(e3));
        CHECK_THROWS(B.erase(4));
    }

}



#endif

