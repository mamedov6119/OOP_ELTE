﻿#include <iostream>
#include "menu.h"
#include "read.hpp"
#include <sstream>
#define menuCount 6 ///number of menu items

using namespace std;

///Check if the given menuitem number exists
bool check(int a){return a>=0 && a<=menuCount;}
bool validate(int a){return true;}


void Menu::Run()
{
    int v;
    do{
        v=MenuPrint();
        switch(v)
        {
            case 1:
                insert();
                print();
                break;
            case 2:
                erase();
                print();
                break;
            case 3:
                rfrequency();
                print();
                break;
            case 4:
                occured_once();
                print();
                break;
             case 5:
                print();
                break;
            default:
                cout<<"\nGoodbye!\n";
                break;

        }
    }while(v!=0);
}

int Menu::MenuPrint()
{
    int choice;
    cout<<"\n****************************************\n";
    cout<<"0. Exit\n";
    cout<<"1. Put in\n";
    cout<<"2. Take out\n";
    cout<<"3. Frequency\n";
    cout<<"4. Once\n";
    cout<<"5. Print the Bag\n";
    cout<<"****************************************\n";
    ///felxible error msg
    ostringstream s;
    s<<"choose a number between 0 and "<<menuCount<<"!";
    string errmsg=s.str();
    ///read with read.hpp
    choice=read<int>("Choose a menuitem: ",errmsg,check);

    return choice;
}

void Menu::insert()
{
    try{
        Item e;
        cin >> e;
        B.insert(e);
        cout<<"Success!\n"<<endl;
    }
    catch(Bag::ExistingKeyException err)
    {
        cerr<<"Insert is unsuccessful. The key already exists!\n";
    }

}

void Menu::erase()
{
    int key = read<int>("Key: ","I need an integer!",validate);
    try{
        B.erase(key);
        cout<<"Success!\n"<<endl;
    }
    catch(Bag::NonExistingKeyException err)
    {
        cerr<<"Take out is unsuccessful, the key does not exist!\n";
    }
}

void Menu::print()
{
    cout<<B;
}

int Menu::rfrequency()
{
    Item e;
    cout << "Element: ";
    cin >> e.element;

    try{

    cout << "Frequency: " << B.rfrequency(e) << endl;
    }
    catch(Bag::NonExistingKeyException err)
    {
        cerr<<"Operation is unsuccessful, the element does not exist!\n";
    }
}

int Menu::occured_once() {
    Item e;
    try{

    cout << "Number of elements appearing only once: " << B.occured_once() << endl;
    }
    catch(Bag::NonExistingKeyException err)
    {
        cerr<<"Operations is unsuccessful, the element does not exist!\n";
    }
}
