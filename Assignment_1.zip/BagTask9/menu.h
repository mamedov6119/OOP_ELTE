#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "bag.h"

class Menu
{
    public:
        Menu(){};
        void Run();
    private:
        int MenuPrint();
        void insert();
        void erase();
        void print();
        int rfrequency();
        int occured_once();
        Bag B;


};

#endif // MENU_H_INCLUDED
