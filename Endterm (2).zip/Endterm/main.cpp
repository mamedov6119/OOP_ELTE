#include <iostream>
#include "library/maxsearch.hpp"
#include "library/linsearch.hpp"
#include "library/summation.hpp"
#include "library/seqinfileenumerator.hpp"
#include "library/counting.hpp"

using namespace std;


struct Data
{
    int round;
    string name;
    int score;
    friend istream& operator>>(istream &is, Data &d);
};

istream& operator>>(istream &is, Data &d)
{
    is >> d.round >> d.name >> d.score;
    return is;
}


class CountAfterSmithy : public Counting<Data>
{
protected:

    bool cond(const Data &e)  const override{return e.score == 10;}
    bool whileCond(const Data &e) const { return 1;}
};

int main()
{
    try
    {
        CountAfterSmithy pr;
        SeqInFileEnumerator<Data> enor("inp.txt");

        pr.addEnumerator(&enor);
        pr.run();
        cout << "Count of strikes in total: " << pr.result();

    } catch (SeqInFileEnumerator<Data>::Exceptions exc)
    {
        cout << "File not found!" << endl;
    }
    return 0;
}
