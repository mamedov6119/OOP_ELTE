#pragma once

#include <string>
#include "Layer.h"


class Variable {

protected:
    char _type;
    Variable(const char &type) : _type(type) {}
public:
    virtual void transmute(Layer* &layer) = 0;
    virtual ~Variable() {}
    char getVar() const {return _type;}


};


class Thunderstorm : public Variable {
public:
    Thunderstorm(const char &type) : Variable(type) {}
    void transmute(Layer* &layer) override {
        layer = layer->transmute(this);
    }
};

class Sunshine : public Variable {
public:
    Sunshine(const char &type) : Variable(type) {}
    void transmute(Layer* &layer) override {
        layer = layer->transmute(this);
    }
};

class Other : public Variable {
public:
    Other(const char &type) : Variable(type) {}
    void transmute(Layer* &layer) override {
        layer = layer->transmute(this);
    }
};
