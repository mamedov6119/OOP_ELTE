#pragma once

#include <string>

class Thunderstorm;
class Sunshine;
class Other;

struct lay
{
    char type;
    double thickness;
};


class Layer {
protected:
    bool needAlayer = false;
    char _type;
    double _thickness;

    Layer(const char &type, double thickness) : _type(type), _thickness(thickness) {}
public:
    lay l;
    bool alive() const {return _thickness > 0.5;}
    char getType() const {return _type;}
    virtual double getThickness() const {return _thickness;}
    void setThickness(double thick) {_thickness = thick*_thickness;}
    void changeThickness(double thick) {

        _thickness -= double(_thickness*thick);
    }


    bool needNewLayer() {return needAlayer;}
    void layerCreated() {needAlayer = false;}
    virtual Layer* transmute(Thunderstorm *p) = 0;
    virtual Layer* transmute(Sunshine *p) = 0;
    virtual Layer* transmute(Other   *p) = 0;
    virtual ~Layer() {}

};


class Ozone : public Layer {
public:
    static Ozone* instance(const char &type, double thickness);
    Layer* transmute(Thunderstorm *p) override;
    Layer* transmute(Sunshine *p) override;
    Layer* transmute(Other   *p) override;
    static void destroy();

    Ozone(const char &type, double thickness) : Layer(type, thickness) {}
private:
    static Ozone* _instance;

};


class Oxygen : public Layer {
public:
    static Oxygen* instance(const char &type, double thickness);
    Layer* transmute(Thunderstorm *p) override;
    Layer* transmute(Sunshine *p) override;
    Layer* transmute(Other   *p) override;
    static void destroy();

    Oxygen(const char &type, double thickness) : Layer(type, thickness) {}
private:
    static Oxygen* _instance;

};


class Carbon : public Layer {
public:
    static Carbon* instance(const char &type, double thickness);
    Layer* transmute(Thunderstorm *p) override;
    Layer* transmute(Sunshine *p) override;
    Layer* transmute(Other   *p) override;
    static void destroy();

    Carbon(const char &type, double thickness) : Layer(type, thickness) {}
private:
    static Carbon* _instance;

};
