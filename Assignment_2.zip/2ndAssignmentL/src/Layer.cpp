#include "Layer.h"
#include "Variables.h"
#include <iostream>
using namespace std;

Ozone* Ozone::_instance = nullptr;
Ozone* Ozone::instance(const char &type, double thickness)
{
    if(_instance == nullptr)
    {
        _instance = new Ozone(type, thickness);
    }
    return _instance;
}
void Ozone::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}


Layer* Ozone::transmute(Thunderstorm *p)
{
    changeThickness(0);

    return this;
}

Layer* Ozone::transmute(Sunshine *p)
{
    changeThickness(0);
    return this;
}

Layer* Ozone::transmute(Other *p)
{


    changeThickness(0.05);


    return this;
}



/////////////////////////////


Oxygen* Oxygen::_instance = nullptr;
Oxygen* Oxygen::instance(const char &type, double thickness)
{
    if(_instance == nullptr)
    {
        _instance = new Oxygen(type, thickness);
    }
    return _instance;
}
void Oxygen::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}


Layer* Oxygen::transmute(Thunderstorm *p)
{

    return this;
}

Layer* Oxygen::transmute(Sunshine *p)
{

    changeThickness(0.05);
    return this;
}

Layer* Oxygen::transmute(Other *p)
{

    changeThickness(0.1);
    return this;
}

///////////////////////////


Carbon* Carbon::_instance = nullptr;
Carbon* Carbon::instance(const char &type, double thickness)
{
    if(_instance == nullptr)
    {
        _instance = new Carbon(type, thickness);
    }
    return _instance;
}
void Carbon::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}


Layer* Carbon::transmute(Thunderstorm *p)
{
    changeThickness(0);
    return this;
}

Layer* Carbon::transmute(Sunshine *p)
{

    changeThickness(0.05);
    return this;
}

Layer* Carbon::transmute(Other *p)
{
    changeThickness(0);
    return this;
}


