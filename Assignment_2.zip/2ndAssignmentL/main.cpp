#include <iostream>
#include <cstdlib>
#include <fstream>
#include <vector>
#include "Variables.h"
#include "Layer.h"
#include <vector>
#include <unordered_map>

using namespace std;


void create(const string &str, vector<Layer*> &layers, vector<Variable*> &vars)
{
    ifstream f(str);
    if(f.fail())
    {
        cout << "Wrong file name!\n";
        exit(1);
    }

    // population of the creatures
    int n;
    f >> n;
    layers.resize(n);
    for( int i=0; i<n; ++i )
    {
        char ch;
        double p;
        f >> ch >> p;
        switch(ch)
        {
        case 'Z' :
            layers[i] = new Ozone(ch,p);
            break;
        case 'X' :
            layers[i] = new Oxygen(ch,p);
            break;
        case 'C' :
            layers[i] = new Carbon(ch,p);
            break;
        }
    }
    // population of the racetrack
    string m;
    f>>m;
    vars.resize(m.size());
    for( unsigned int j=0; j< m.length(); ++j )
    {
        switch(m[j])
        {
        case 'T' :
            vars[j] = new Thunderstorm(m[j]);
            break;
        case 'S' :
            vars[j] = new Sunshine(m[j]);
            break;
        case 'O' :
            vars[j] = new Other(m[j]);
            break;
        }
    }
}


bool IfPerished(vector<Layer*> &layers)
{
    bool l = true;
    for (unsigned int i = 0; i < layers.size(); i++)
    {
        if(!layers[i]->alive())
        {
            l = false;
        }
    }
    return l;
}

/*

        vector<Layer*>::iterator it;
    for(it=layers.begin(); it!=layers.end();)
     {
         Layer *temp = *it;
         if(!temp->alive())
             it=layers.erase(it);
         else
             ++it;
     }
     for (unsigned int j = 0; j < layers.size(); j++) {
                cout << layers[j]->getType() << " " << layers[j]->getThickness() << endl;
                cout << "_____________" << endl;
        }

            cout << layers.size() << endl;


        unordered_map<char, Layer*> MyMap;
         for (unsigned int j = 0; j < layers.size(); j++) {
            if (layers[j]->getType() == 'Z') {
                MyMap.insert(pair<char, Layer*>('Z',layers[j]));
            } else if (layers[j]->getType() == 'X') {
                MyMap.insert(pair<char, Layer*>('X',layers[j]));
            } else if (layers[j]->getType() == 'C') {
                MyMap.insert(pair<char, Layer*>('C',layers[j]));
            }
         }

         for (auto pair : MyMap)
         {
             cout << pair.first << " " << pair.second << endl;
         }



                    unsigned int s = i;
                    unsigned int ind;
                if (i > 0) {
                    while(layers[s]->getType() != layers[i]->getType() && s != 0)
                    {
                        ind = s;
                        s--;
                    }
                    layers[ind]->changeThickness(layers[i]->getThickness());
                    delete layers[i];
                    cout << layers.size() << endl;
                } else {
                    cout << "Else" << endl;
                }
    */


vector<Layer*> dupRemove(vector<Layer*> &layers)
{
    vector<Layer*> temp;
    int size = 0;

    if (layers.size() == 1) return layers;


    for (unsigned int i = 0; i < layers.size() - 1; i++)
    {
        if (size == 0 || layers[i]->getType() != layers[i+1]->getType())
        {
            temp.push_back(layers[i]);
            size++;
        }
        else
        {
            temp[size-1]->setThickness(temp[size-1]->getThickness() + layers[i+1]->getThickness());
        }
    }


    return temp;
}

void race(vector<Layer*> &layers, vector<Variable*> &vars)
{
    try
    {
        unsigned int k = 0;
        unsigned int v = 0;

        while (IfPerished(layers))
        {
            for (unsigned int z = 0; z < layers.size(); z++)
            {
                cout << layers[z]->getType() << " " << layers[z]->getThickness() << endl;
            }

            if(v == vars.size()-1) v = 0;

            cout << "Round " << k+1 << endl;

            for (unsigned int i = 0;  i < layers.size(); i++)
            {
                vars[v]->transmute(layers[i]);
                for (unsigned int z = 0; z < layers.size(); z++)
                {
                    cout << layers[z]->getType() << " " << layers[z]->getThickness() << endl;
                }

                if (i > 0)
                {

                    if (layers[i]->getType() == 'Z' && vars[v]->getVar() == 'O')
                    {
                        layers.insert(layers.begin()+i-1, new Oxygen('X', layers[i]->getThickness()*0.05));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'T')
                    {
                        layers.insert(layers.begin()+i-1, new Ozone('Z', layers[i]->getThickness()*0.5));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'S')
                    {
                        layers.insert(layers.begin()+i-1, new Ozone('Z', layers[i]->getThickness()*0.05));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'O')
                    {
                        layers.insert(layers.begin()+i-1, new Carbon('C', layers[i]->getThickness()*0.1));

                    }
                    else if (layers[i]->getType() == 'C' && vars[v]->getVar() == 'S')
                    {

                        layers.insert(layers.begin()+i-1, new Oxygen('X', layers[i]->getThickness()*0.05));

                    }
                }
                else
                {

                    if (layers[i]->getType() == 'Z' && vars[v]->getVar() == 'O')
                    {
                        layers.insert(layers.begin(), new Oxygen('X', layers[i]->getThickness()*0.05));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'T')
                    {
                        layers.insert(layers.begin(), new Ozone('Z', layers[i]->getThickness()*0.5));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'S')
                    {
                        layers.insert(layers.begin(), new Ozone('Z', layers[i]->getThickness()*0.05));

                    }
                    else if (layers[i]->getType() == 'X' && vars[v]->getVar() == 'O')
                    {
                        layers.insert(layers.begin(), new Carbon('C', layers[i]->getThickness()*0.1));

                    }
                    else if (layers[i]->getType() == 'C' && vars[v]->getVar() == 'S')
                    {
                        layers.insert(layers.begin(), new Oxygen('X', layers[i]->getThickness()*0.05));

                    }

                }



                i++;


            }


            k++;
            v++;
            layers = dupRemove(layers);


        }


        cout << "___________________" << endl;
        for (unsigned int z = 0; z < layers.size(); z++)
        {
            cout << layers[z]->getType() << " " << layers[z]->getThickness() << endl;

        }
        cout << "___________________" << endl;

    }
    catch(exception e)
    {
        cout << e.what() << endl;
    }
}







void destroy(vector<Variable*> &vars)
{
    for(int i=0; i<(int)vars.size(); ++i) delete vars[i];
}

void destroyLayers()
{
    Ozone::destroy();
    Oxygen::destroy();
    Carbon::destroy();
}

//#ifndef NORMAL_MOD
#ifdef NORMAL_MOD

int main()
{


    vector<Layer*> layers;
    vector<Variable*> vars;
    create("inp.txt", layers, vars);
    race(layers, vars);

    destroy(vars);
    destroyLayers();
    return 0;
}

/*

Round 1
Z 4.75
X 0.8
C 3
X 4
X 0.2375
Z 4.75
X 0.72
C 3
X 4
X 0.2375
C 0.072
Z 4.75
X 0.72
C 3
X 4
*/



#else
#define CATCH_CONFIG_MAIN
#include "catch.hpp"

TEST_CASE("1", "inp*.txt")
{
    vector<Layer*> layers;
    vector<Variable*> vars;


    create("inp.txt", layers, vars);
    CHECK(layers.size() == 4);
    CHECK(vars.size() == 11);
    CHECK(layers[0]->getType() == 'X');
    race(layers,vars);


    destroy(vars);
    destroyLayers();

    create("inp2.txt", layers, vars );
    CHECK(layers.size() == 10);
    CHECK(vars.size() == 6);
    CHECK(layers[0]->getType() == 'C');
    race(layers,vars);

    destroy(vars);
    destroyLayers();

    create("inp3.txt", layers, vars );
    CHECK(layers.size() == 8);
    CHECK(vars.size() == 11);
    CHECK(layers[0]->getType() == 'Z');
    race(layers,vars);

    destroy(vars);
    destroyLayers();

}

#endif
