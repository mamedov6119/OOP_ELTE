#include <iostream>
#include "library/maxsearch.hpp"
#include "library/linsearch.hpp"
#include "library/seqinfileenumerator.hpp"
#include "library/summation.hpp"
#include "library/stringstreamenumerator.hpp"
#include "library/counting.hpp"
#include "library/selection.hpp"
#include "library/procedure.hpp"
#include "library/intervalenumerator.hpp"
#include "library/arrayenumerator.hpp"

using namespace std;


/* 2ND TASK :  Has every angler caught a catfish bigger than 30 cm? */

struct Fish
{
    string fish;
    int size;
    friend istream &operator>>(istream &is, Fish &f)
    {
        is >> f.fish >> f.size;
        return is;
    }
};

class caughtCatfish30 : public LinSearch<Fish>
{
    bool cond(const Fish &f) const override
    {
        return f.fish=="catfish" && f.size > 30;
    }
};

struct Angler
{
    string name;
    string id;
    bool is_catfish = false;
    int cfsize;

    friend istream &operator>>(istream &is, Angler &a)
    {
        string line;
        getline(is, line, '\n');
        stringstream ss(line);
        ss>>a.name>>a.id;
        StringStreamEnumerator<Fish> ssenor(ss);
        caughtCatfish30 pr;
        pr.addEnumerator(&ssenor);
        pr.run();
        a.is_catfish = pr.found();
        a.cfsize = pr.elem().size;
        return is;
    }
};

struct Contest
{
    string name;
    bool catch_fish;

    Contest(): name(""), catch_fish(false) {}
    Contest(const string &con, int increment) : name(con), catch_fish(increment) {}
};

class contestResult : public Summation<Angler, Contest>
{
public:
    contestResult(const string &contestId) : _contestId(contestId) {}
private:
    string _contestId;

    Contest func(const Angler &a) const override
    {
        return Contest(a.name, (a.is_catfish && a.cfsize > 30) ? true : false);
    }
    Contest neutral() const override
    {
        return Contest();
    }
    Contest add(const Contest &a, const Contest &b) const override
    {
        return Contest(b.name, b.catch_fish || a.catch_fish);
    }

    void first() override {}
    bool whileCond(const Angler& current) const override
    {
        return current.name == _contestId;
    }
};

class ContestEnum : public Enumerator<Contest>
{
private:
    SeqInFileEnumerator<Angler>* _f;
    Contest _contest;
    bool _end;

    bool _empty;
public:
    ContestEnum(const string &id): _empty(true)
    {
        _f = new SeqInFileEnumerator<Angler>(id);
    }
    ~ContestEnum()
    {
        delete _f;
    }
    void first() override
    {
        _f->first();
        next();
        if (!end()) _empty = false;
    }
    void next() override;
    Contest current() const override
    {
        return _contest;
    }
    bool end() const override
    {
        return _end;
    }
    bool getEmpty() const
    {
        return _empty;
    }
};

void ContestEnum::next()
{
    if ((_end = _f->end()))return;
    _contest.name = _f->current().name;
    contestResult pr(_contest.name);
    pr.addEnumerator(_f);
    pr.run();
    _contest = pr.result();
}

class AllCatFish : public LinSearch<Contest>
{
protected:
    bool cond(const Contest& c) const override
    {
        return !c.catch_fish;
    }
};

    /*
int main()
{
    try
    {
        AllCatFish pr;
        ContestEnum enor("inp1.txt");
        pr.addEnumerator(&enor);
        pr.run();

        if (pr.found())
        {
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
            cout << "Not all of the Anglers has caught a catfish bigger than 30cm!" << endl;
            cout << "_____________________________________________________________" << endl;
        }
        else
        {
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
            cout << "Every Angler has caught a catfish bigger than 30cm!" << endl;
            cout << "_____________________________________________________________" << endl;
        }

    }
    catch(SeqInFileEnumerator<Angler>::Exceptions ex)
    {
        if(SeqInFileEnumerator<Angler>::OPEN_ERROR == ex)
        {
            cout << "Wrong file name!\n";
            return 1;
        }
    }
    return 0;
}
    */

