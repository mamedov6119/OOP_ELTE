#include <iostream>
#include "library/maxsearch.hpp"
#include "library/linsearch.hpp"
#include "library/seqinfileenumerator.hpp"
#include "library/summation.hpp"
#include "library/stringstreamenumerator.hpp"
#include "library/counting.hpp"
#include "library/selection.hpp"
#include "library/procedure.hpp"
#include "library/intervalenumerator.hpp"
#include "library/arrayenumerator.hpp"
using namespace std;

/* 1ST TASK : Give the biggest caught catfish with its size, the contest ID and the angler’s name. */


struct Fish
{
    string fish;
    int size;

    friend istream &operator>>(istream &is, Fish &f)
    {
        is >> f.fish >> f.size;
        return is;
    }
};

struct BiggestFish
{
    int maxcat;
    bool iscat;

    BiggestFish() {}
    BiggestFish(int a, bool b) : maxcat(a), iscat(b) {}
};

class readAngler : public Summation<Fish, BiggestFish>
{
    BiggestFish func(const Fish &f) const override
    {
        return BiggestFish(f.fish=="catfish"? f.size : 0, f.fish== "catfish" ? true : false);
    }

    BiggestFish neutral() const override
    {
        return BiggestFish (0, false);
    }

    BiggestFish add (const BiggestFish &a, const BiggestFish &b) const override
    {
        return (a.maxcat > b.maxcat) ? BiggestFish(a.maxcat, a.iscat) : BiggestFish(b.maxcat, b.iscat);
    }
};

struct Angler
{
    string name;
    string id;
    int fsize;
    bool catf;

    friend istream &operator>>(istream &is, Angler &a)
    {
        string line;
        getline(is, line, '\n');
        stringstream ss(line);
        ss >> a.name >> a.id;
        StringStreamEnumerator<Fish> enor(ss);

        readAngler pr;
        pr.addEnumerator(&enor);
        pr.run();
        a.fsize = pr.result().maxcat;
        a.catf = pr.result().iscat;

        return is;
    }
};

class BiggestCatFish : public MaxSearch <Angler, int, Greater<int>>
{
    int func (const Angler &a) const override
    {
        return a.fsize;
    }
    bool cond (const Angler &a) const override
    {
        return a.catf;
    }
};


//   /*
int main()
{
    try
    {
        SeqInFileEnumerator<Angler> enor("inp2.txt");
        BiggestCatFish pr;
        pr.addEnumerator(&enor);

        pr.run();

        if (pr.found() && pr.optElem().fsize != 0 && pr.optElem().catf)
        {
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
            cout << "Size of the biggest catfish: " << pr.optElem().fsize << "cm. " << "ID: " << pr.optElem().id << ". Name: " << pr.optElem().name << endl;
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
        }
        else
        {
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
            cout << "No catfishes were caught" << endl;
            cout << "_____________________________________________________________" << endl;
            cout <<  endl;
        }
    }
    catch(SeqInFileEnumerator<Angler>::Exceptions ex)
    {
        if(SeqInFileEnumerator<Angler>::OPEN_ERROR == ex)
        {
            cout << "Wgrong name of the file!\n";
            return 1;
        }
    }
    return 0;
}
 //   */
