#include <iostream>
#include <fstream>

using namespace std;

enum Status
{
    norm,
    abnorm
};


struct Points {
    string name;
    int points;
};

void afterSamy(fstream &x);
void includingSamy(fstream &x);
std::istream& operator>>(std::istream& is, const Points &p);
void read (Status &st, Points &d, fstream &f);
string readFileName(fstream &x);
void execute(int n, fstream &f);
string readFileName()
{
    cout << "File Name: ";
    string fileName;
    cin >> fileName;
    return fileName;
}


void read(Status &st, Points &d, fstream &f)
{
    f >> d.name >> d.points;
    if(f.fail()) {
        st = abnorm;
    } else {
        st = norm;
    }
}

istream& operator>>(istream& is, Points &d)
{
    is >> d.name >> d.points;
    return is;
}

void menuPrint()
{
    cout << "\n0. Exit\n";
    cout << "1. After Samy\n";
    cout << "2. Including Samy\n";
    cout << "Choose: ";
}

void execute(int n, fstream &f)
{
    switch (n)
    {
    case 1:
        afterSamy(f);
        break;
    case 2:
        includingSamy(f);
        break;
    }
}


void afterSamy(fstream &x)
{

    Status st;
    Points e;
    read(st, e, x);
    bool lessthanfive = false;
    while (e.name == "Samy" && st == norm)
    {
        //lessthanfive = true;
        //cout << e.name << e.points << " Not" << endl;
        read(st,e,x);
    }

    read(st,e,x);
    while(st==norm)
    {
        if (e.points < 5) {
            lessthanfive = true;
            //cout << e.name << e.points << " Not" << endl;
        }
        read(st,e,x);
    }
        if (lessthanfive) {
            cout << "Yes, there is! ( NOT Inlcuding Samy)" << endl;
        } else {
            cout << "No, there is no person with less than 5 points! (NOT Inlcuding Samy)" << endl;
        }
}


void includingSamy(fstream &x) {
    Status st;
    Points e;
    read(st, e, x);
    bool lessthanfive1 = false;
    while ( e.name != "Samy" && st == norm)
    {
        lessthanfive1 = true;
        read(st,e,x);
    }

    read(st,e,x);
    while(e.points && st==norm)
    {
        if (e.points < 5) {
            lessthanfive1 = true;
           // cout << e.name << e.points << endl;
        }
        read(st,e,x);
    }
        if (lessthanfive1) {
            cout << "Yes, there is! (Inlcuding Samy)" << endl;
        } else {
            cout << "No, there is no person with less than 5 points! (Inlcuding Samy)" << endl;
        }
}






int main()
{
    int menuItem = 3; /// if it is not set and wrong file name is given for the first time, the program terminates
    do
    {
        menuPrint();
        cin >> menuItem;
        if (menuItem > 0 && menuItem < 4)
        {
            fstream file(readFileName());
            if (!file.fail())
            {
                execute(menuItem, file);
                file.close();
            }
            else
            {
                cout << "Wrong file name!\n";
            }
        }
    } while (menuItem != 0);

    return 0;
}
